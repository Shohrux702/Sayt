from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from models import Course, Enrollment

main = Blueprint('main', __name__)

@main.route('/')
def index():
    """Bosh sahifa"""
    courses = Course.query.order_by(Course.created_at.desc()).limit(6).all()
    return render_template('main/index.html', courses=courses)

@main.route('/profile')
@login_required
def profile():
    """Foydalanuvchi profili"""
    if current_user.role == 'student':
        enrollments = Enrollment.query.filter_by(student_id=current_user.id).all()
        return render_template('main/profile.html', enrollments=enrollments)
    else:
        courses = Course.query.filter_by(teacher_id=current_user.id).all()
        return render_template('main/profile.html', courses=courses)
