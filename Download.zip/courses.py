from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import Course, Enrollment, db

courses = Blueprint('courses', __name__)

@courses.route('/courses')
def list():
    """Barcha kurslar ro'yxati"""
    courses = Course.query.order_by(Course.created_at.desc()).all()
    return render_template('courses/list.html', courses=courses)

@courses.route('/courses/create', methods=['GET', 'POST'])
@login_required
def create():
    """Yangi kurs yaratish (faqat o'qituvchilar uchun)"""
    if current_user.role != 'teacher':
        flash("Faqat o'qituvchilar kurs yarata oladi", 'danger')
        return redirect(url_for('main.index'))
        
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        course = Course(title=title, description=description, teacher_id=current_user.id)
        db.session.add(course)
        db.session.commit()
        
        flash('Kurs muvaffaqiyatli yaratildi!', 'success')
        return redirect(url_for('courses.view', course_id=course.id))
        
    return render_template('courses/create.html')

@courses.route('/courses/<int:course_id>')
def view(course_id):
    """Kurs ma'lumotlarini ko'rish"""
    course = Course.query.get_or_404(course_id)
    is_enrolled = False
    if current_user.is_authenticated:
        is_enrolled = Enrollment.query.filter_by(
            student_id=current_user.id,
            course_id=course_id
        ).first() is not None
    return render_template('courses/view.html', course=course, is_enrolled=is_enrolled)

@courses.route('/courses/<int:course_id>/enroll', methods=['POST'])
@login_required
def enroll(course_id):
    """Kursga yozilish"""
    if current_user.role != 'student':
        flash("Faqat o'quvchilar kurslarga yozilishi mumkin", 'danger')
        return redirect(url_for('courses.view', course_id=course_id))
        
    course = Course.query.get_or_404(course_id)
    if Enrollment.query.filter_by(student_id=current_user.id, course_id=course_id).first():
        flash('Siz allaqachon bu kursga yozilgansiz', 'info')
    else:
        enrollment = Enrollment(student_id=current_user.id, course_id=course_id)
        db.session.add(enrollment)
        db.session.commit()
        flash('Kursga muvaffaqiyatli yozildingiz!', 'success')
        
    return redirect(url_for('courses.view', course_id=course_id))
