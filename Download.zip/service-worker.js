
// Service Worker for Caching and Offline Access
const CACHE_NAME = 'qishloq-talimi-cache-v1';
const COURSE_CACHE_NAME = 'courses-cache';

// Files to cache for the application shell
const appShellFiles = [
  '/',
  '/static/css/main.css',
  '/static/js/main.js',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
  'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css'
];

// Install event - cache the application shell
self.addEventListener('install', event => {
  console.log('[Service Worker] Install');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[Service Worker] Caching app shell');
      return cache.addAll(appShellFiles);
    })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('[Service Worker] Activate');
  event.waitUntil(
    caches.keys().then(keyList => {
      return Promise.all(
        keyList.map(key => {
          if (key !== CACHE_NAME && key !== COURSE_CACHE_NAME) {
            console.log('[Service Worker] Removing old cache', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  return self.clients.claim();
});

// Fetch event - serve from cache if available
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  
  // For API requests to download course data
  if (url.pathname.match(/\/api\/courses\/\d+\/download/)) {
    event.respondWith(
      caches.open(COURSE_CACHE_NAME)
        .then(cache => cache.match(event.request))
        .then(response => response || fetch(event.request))
    );
    return;
  }
  
  // For offline-first pages
  if (url.pathname.startsWith('/offline')) {
    event.respondWith(
      caches.match(event.request)
        .then(response => response || fetch(event.request))
        .catch(() => {
          // If both cache and network fail, return offline page
          return caches.match('/offline/fallback');
        })
    );
    return;
  }
  
  // Default fetch strategy - network first, fallback to cache
  event.respondWith(
    fetch(event.request)
      .then(response => {
        // Cache GET requests for common resources
        if (event.request.method === 'GET' && 
            (event.request.url.includes('/static/') || 
             event.request.url.includes('cdn.jsdelivr.net'))) {
          const responseClone = response.clone();
          caches.open(CACHE_NAME)
            .then(cache => cache.put(event.request, responseClone));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

// Handle background sync for data synchronization
self.addEventListener('sync', event => {
  if (event.tag === 'sync-progress') {
    event.waitUntil(syncProgress());
  }
});

// Function to sync offline progress data
async function syncProgress() {
  try {
    const db = await openIndexedDB();
    const tx = db.transaction('progressUpdates', 'readonly');
    const store = tx.objectStore('progressUpdates');
    const allRecords = await store.getAll();
    
    for (const record of allRecords) {
      try {
        const response = await fetch('/offline/sync', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(record),
        });
        
        if (response.ok) {
          // If successfully synced, remove from IndexedDB
          const deleteTx = db.transaction('progressUpdates', 'readwrite');
          const deleteStore = deleteTx.objectStore('progressUpdates');
          await deleteStore.delete(record.id);
        }
      } catch (error) {
        console.error('Error syncing record:', error);
      }
    }
    
    db.close();
  } catch (error) {
    console.error('Sync error:', error);
  }
}

// Helper function to open IndexedDB
function openIndexedDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('offlineProgressDB', 1);
    
    request.onupgradeneeded = event => {
      const db = event.target.result;
      db.createObjectStore('progressUpdates', { keyPath: 'id', autoIncrement: true });
    };
    
    request.onsuccess = event => resolve(event.target.result);
    request.onerror = event => reject(event.target.error);
  });
}
