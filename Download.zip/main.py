import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from sqlalchemy.orm import DeclarativeBase

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
login_manager = LoginManager()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

# Configure database with PostgreSQL
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db.init_app(app)
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Iltimos, tizimga kiring'

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Initialize database and register blueprints
with app.app_context():
    # Import models here to ensure they're registered
    from models import User, Course, Lesson, Enrollment, Progress
    db.create_all()

    # Import and register blueprints
    from routes.auth import auth
    from routes.main import main
    from routes.courses import courses
    from routes.react_app import react_app
    from routes.videos import videos
    from routes.offline import offline

    app.register_blueprint(auth)
    app.register_blueprint(main)
    app.register_blueprint(courses)
    app.register_blueprint(react_app)
    app.register_blueprint(videos)
    app.register_blueprint(offline)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)